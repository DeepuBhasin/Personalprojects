<?php
session_start();
require 'vendor/autoload.php';

use Google\Cloud\Vision\VisionClient;

$Vision = new VisionClient(['keyFile' => json_decode(file_get_contents('key.json'), true)]);

$familyPhotoResourse = fopen($_FILES['image']['tmp_name'], 'r');

$image = $Vision->image($familyPhotoResourse, ['FACE_DETECTION', 'WEB_DETECTION']);

$result = $Vision->annotate($image);

if ($result) {
    $imageToken = random_int(111111, 9999999);
    move_uploaded_file($_FILES['image']['tmp_name'], 'images/' . $imageToken . '.jpg');
} else {
    header('location:index.php');
    die();
}

$faces=$result->faces();
$logos=$result->logos();
$labels=$result->labels();
$text=$result->text();
$fullText=$result->fullText();
$imageProperties=$result->imageProperties();
$cropHints=$result->cropHints();
$web=$result->web();
$safeSearch=$result->safeSearch();
$landmarks=$result->landmarks();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Cloud vision</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
    <style type="text/css">
    body,
    html {
        height: 100%;

    }

    .bg {
        background-image: url('bg.jpg');
        background-repeat: no-repeat;
        height: 100%;
        background-position: center;
        background-size: cover;

    }
    </style>
</head>

<body class="bg">
    <div class="container-fluid" style="max-width: 1080px;">
        <br /><br /><br />
        <div class="row">
            <div class="col-md-12" style="margin:auto;background:white;padding:20px;box-shadow:10px 10px 5px #880">
                <div class="panel-heading">
                    <h2><a href="/">Google Cloud Vision Api</a> </h2>
                    <p style="font-style:italic;">Coolest Image Processing Engine on Earth </p>
                </div>
                <hr>

                <div class="row">
                	<div class="col-md-4" style="text-align: center;">
                		<img class="img-thumbnail" src="<?php  
                			if($face=null){
                				echo"images/".$imageToken.".jpg";
                			}else{
                				echo "images/".$imageToken.".jpg";
                			}


                		?>" alt="Analysed Image">
                	</div>
                	<div class="col-md-8 border" style="padding: 10px">
                		  <ul class="nav nav-pills nav-fill mb-3" id="pills-tab" role="tablist">
                              <li class="nav-item">
                                  <a href="#pills-face" role="tab" class="nav-link active" id="pills-face-tab" data-toggles="pill" aria-controls="pills-face" aria-seleted="true">Faces</a>
                              </li>
                              <li class="nav-item">
                                  <a href="#pills-labels" role="tab" class="nav-link" id="pills-labels-tab" data-toggles="pill" aria-controls="pills-labels" aria-seleted="true">Labels</a>
                              </li>

                              <li class="nav-item">
                                  <a href="#pills-web" role="tab" class="nav-link" id="pills-web-tab" data-toggles="pill" aria-controls="pills-web" aria-seleted="true">Web</a>
                              </li>
                              <li class="nav-item">
                                  <a href="#pills-properties" role="tab" class="nav-link" id="pills-properties-tab" data-toggles="pill" aria-controls="pills-properties" aria-seleted="true">Properties</a>
                              </li>
                              <li class="nav-item">
                                  <a href="#pills-safesearch" role="tab" class="nav-link" id="pills-safesearch-tab" data-toggles="pill" aria-controls="pills-safesearch" aria-seleted="true">Safe Search</a>
                              </li>
                              <li class="nav-item">
                                  <a href="#pills-landmarks" role="tab" class="nav-link" id="pills-landmarks-tab" data-toggles="pill" aria-controls="pills-landmarks" aria-seleted="true">Land Marks</a>
                              </li>
                              <li class="nav-item">
                                  <a href="#pills-logo" role="tab" class="nav-link" id="pills-logo-tab" data-toggles="pill" aria-controls="pills-logo" aria-seleted="true">Logos</a>
                              </li>
                          </ul>
                          <hr>
                          <div class="tab-content" id="pills-tabContent">
                              <div class="tab-pane fade show active" id="pills-face" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/faces.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>


                              <div class="tab-pane fade show" id="pills-labels" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/labels.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>


                              <div class="tab-pane fade show active" id="pills-web" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/web.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>

                              <div class="tab-pane fade show active" id="pills-properties" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/properties.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>

                              <div class="tab-pane fade show active" id="pills-safesearch" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/safesearch.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>

                              <div class="tab-pane fade show active" id="pills-landmarks" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/landmarks.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>

                              <div class="tab-pane fade show active" id="pills-logos" role="tabpanel" aria-labeldby="pills-label-tab">
                                  <div class="row">
                                      <div class="col-12">
                                          <?php include 'phpfiles/logos.php';

                                          ?>
                                      </div>
                                  </div>
                              </div>
                        </div>
                	</div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

